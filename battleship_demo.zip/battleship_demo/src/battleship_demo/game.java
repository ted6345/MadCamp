package battleship_demo;

public class game {

	public static void main(String[] args){
		
		board player1 = new board();
		board player2 = new board();
		boolean still_playing=true;
		
		int turn=0;
		
		
		
		// player1, player2���� ���� ��ǥ�� setting �ϴ� �۾� 
//		player1.setting(int[][] setting);
//		player2.setting(int[][] setting);
//		
		while(still_playing)
		{
			int[] coordinate = new int[2];
			turn++;
			switch(turn%2)
			{
			case 0:
					coordinate=player1.turn();
					player2.opponent_turn(coordinate);
			case 1:
					player2.turn();
			
			}
			
			
			
		}
		
		
		
		
	}
}

