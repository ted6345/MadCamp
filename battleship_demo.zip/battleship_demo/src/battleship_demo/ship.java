package battleship_demo;

public class ship {


	private int[][] kill;
	private int count=4;
	private int size=count;
	private int[][] coordinate= new int[2][size];
	public void create(int[][] _coordinate)
	{
		coordinate = _coordinate;
		

		
	}
	//kill �Ǿ����� �� methcod
	public int[][] make_kill()
	{
		//killsize�� ���ؾ���!!
		//int [][] kill = new int[2][killsize];
		int i,j,k;
		if(size==1)
			for(i=0;i<=2;i++)
			{
				
			}
		
		else{
			
		}
	return kill;		
	}
	
	public boolean hit(int x, int y)
	{
		count--;
		if(count==0)
			return true;
		else return false;
	}
	
}
