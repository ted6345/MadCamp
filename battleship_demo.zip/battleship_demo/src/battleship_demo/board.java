package battleship_demo;

import java.lang.reflect.Method;

public class board {

	boolean something;

	ship[] setofship = new ship[10];

	int[][] initialboard = new int[10][10];
	int[][] board = new int[10][10];
	int[] targetcoordinate = new int[2];

	// ��������!!
	class ship_four extends ship {

	}

	class ship_three extends ship {

	}

	class ship_two extends ship {

	}

	class ship_one extends ship {

	}

	public void setting(int setting[][]) {
		initialboard = setting;
		board = setting;
		ship_four ship1 = new ship_four();
		ship_three ship2 = new ship_three();
		ship_three ship3 = new ship_three();
		ship_two ship4 = new ship_two();
		ship_two ship5 = new ship_two();
		ship_two ship6 = new ship_two();
		ship_one ship7 = new ship_one();
		ship_one ship8 = new ship_one();
		ship_one ship9 = new ship_one();
		ship_one ship10 = new ship_one();
	}

	public int[] turn() {
		targetcoordinate[0] = 11;
		targetcoordinate[1] = 11;
		while (true) {
			if (targetcoordinate[0] != 11 && targetcoordinate[1] != 11)
				return targetcoordinate;
		}
	}

	public void opponent_turn(int[] attack) {
		int[][] tmp = new int[11][11];
		switch (board[attack[0]][attack[1]]) {
		case 0:
			board[attack[0]][attack[1]] = 11;
			break;
		default:
			board[attack[0]][attack[1]] = 11;
			// ship class�� ��ǥ�� �������־����

			if (setofship[board[attack[0]][attack[1]]]
					.hit(attack[0], attack[0])) {
				tmp = setofship[board[attack[0]][attack[1]]].make_kill();
				int i = 0;
				while (tmp[0][i] != 11 && tmp[1][i] != 11) {
					board[tmp[0][i]][tmp[1][i]] = 11;

					// imageView!!
				}

				break;
			}

		}

	}
}
