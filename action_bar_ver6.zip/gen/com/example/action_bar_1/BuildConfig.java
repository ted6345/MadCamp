/** Automatically generated file. DO NOT MODIFY */
package com.example.action_bar_1;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}