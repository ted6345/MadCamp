package battleship_demo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.util.ArrayList;

public class board {

	boolean something;
	private boolean still_board = true;
	int[][] initialboard = new int[10][10];
	int[][] board = new int[10][10];
	int[] targetcoordinate = new int[2];
	int life = 10; 
	
	ArrayList<ship> setofship = new ArrayList<ship>();
	
	public boolean getstill_board() {
		return still_board;
	}
//	public void setstill_board(boolean t) {
//		still_board = t;
//	}
	public void settargetcoordinate(int[] t)
	{
		targetcoordinate = t;
	}
	
	class ship_four extends ship {
		private int count = 4;
		private int size = count;
		private int[][] coordinate= new int[2][size];
		
	}

	class ship_three extends ship {
		private int count = 3;
		private int size = count;
		private int[][] coordinate= new int[2][size];		
		
	}

	class ship_two extends ship {
		private int count = 2;
		private int size = count;
		private int[][] coordinate= new int[2][size];
		
	}

	class ship_one extends ship {
		private int count = 1;
		private int size = count;
		private int[][] coordinate= new int[2][size];
		
	}

	public void setting(int setting[][]) {
		initialboard = setting;
		board = setting;
		
		ship_four ship1 = new ship_four();
		ship_three ship2 = new ship_three();
		ship_three ship3 = new ship_three();
		ship_two ship4 = new ship_two();
		ship_two ship5 = new ship_two();
		ship_two ship6 = new ship_two();
		ship_one ship7 = new ship_one();
		ship_one ship8 = new ship_one();
		ship_one ship9 = new ship_one();
		ship_one ship10 = new ship_one();
		
		// ship class�� ��ǥ�� �������־����
		
		setofship.add(1,ship1);
		setofship.add(2,ship2);
		setofship.add(3,ship3);
		setofship.add(4,ship4);
		setofship.add(5,ship5);
		setofship.add(6,ship6);
		setofship.add(7,ship7);
		setofship.add(8,ship8);
		setofship.add(9,ship9);
		setofship.add(10,ship10);
	}

	public int[] turn() {
		String a = null,b = null;
		targetcoordinate[0] = 11;
		targetcoordinate[1] = 11;
//		Thread t = new Thread() {
//			public void run() {
//			
//				
//			}
//
//		};
//		t.run();
		while (true) {
			
			BufferedReader buf = new BufferedReader(new InputStreamReader(System.in));
			BufferedReader buf2 = new BufferedReader(new InputStreamReader(System.in));
			try {
				a=buf.readLine();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				b=buf2.readLine();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			targetcoordinate[0]=Integer.parseInt(a);
			targetcoordinate[1]=Integer.parseInt(b);
			
			if (targetcoordinate[0] != 11 && targetcoordinate[1] != 11)
				{
				return targetcoordinate;
				}

		}
	
	}

	public void opponent_turn(int[] attack) {
		int[][] tmp = new int[11][11];
		switch (board[attack[0]][attack[1]]) {
		case 0:
			board[attack[0]][attack[1]] = 11;
			life--;
			if(life==0) still_board =false;
			break;
		default:
			board[attack[0]][attack[1]] = 11;
			if (setofship.get(board[attack[0]][attack[1]]).hit(attack[0],attack[0])) {
				tmp = setofship.get(board[attack[0]][attack[1]]).make_kill();
				int i = 0;
				while (tmp[0][i] != 11 && tmp[1][i] != 11) {
					board[tmp[0][i]][tmp[1][i]] = 11;
					i++;
					if (i == 11)  break;
				}
				life--;
				if(life==0) still_board =false;
			}
			break;
		}

	}
}
