package battleship_demo;

public class ship {

	int size;
	int[][] kill;
	int[][] coordinate;
	int count;
	
	public void setcoordinate(int[][] _coordinate)
	{
		coordinate = _coordinate;
	}
	
	
	public int[][] make_kill()
	{
		// ��ǥ�� �޾Ƽ� ��ǥ�� ��ȯ��
		return kill;		
	}
	
	public boolean hit(int x, int y)
	{
		count--;
		if(count==0)
			return true;
		else return false;
	}
	
}
