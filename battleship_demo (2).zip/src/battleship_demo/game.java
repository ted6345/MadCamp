package battleship_demo;

public class game {

	static int[][] board_setting = new int[10][10];

	public void setboard_setting(int[][] t) {
		board_setting = t;
	}

	public int[][] getboard_setting() {
		return board_setting;
	}

	public static void main(String[] args) {

		boolean still_playing = true;
		int turn = 0;

		board player1 = new board();
		board player2 = new board();
		
		player1.setting(board_setting);
		player2.setting(board_setting);
		
		while (still_playing) {
			int[] coordinate = new int[2];
			switch (turn % 2) {
			case 0:
				coordinate = player1.turn();
				player2.opponent_turn(coordinate);
				still_playing=player2.getstill_board();
				break;
			case 1:
				coordinate = player2.turn();
				player1.opponent_turn(coordinate);
				still_playing=player1.getstill_board();
				break;
			}
			turn++;
		}
          
	}
}
