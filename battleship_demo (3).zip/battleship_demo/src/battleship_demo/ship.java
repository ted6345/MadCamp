package battleship_demo;

public class ship {

	int size;
	int[][] kill;
	int[][] coordinate;
	int count;
	int min=99,max=0,parallel,parallel_value;
	
	
	
	public void setcoordinate(int[][] _Board,int id)
	{
		int i,j,k=0;
		for(i=0;i<10;i++)
		{
			for(j=0;j<10;j++)
			{
				if(_Board[i][j]==id)
				{
					coordinate[0][k]=i;
					coordinate[1][k++]=j;
					if(i<min)	min = i;
					if(j<min)	min = i;
					if(i>max)	max = i;
					if(j<max)	max = j;
				}
			}
		}
		
		if(coordinate[0][0]==coordinate[0][1])
			{
			parallel=0;
			parallel_value=coordinate[0][0];
			}
		else
		{
			parallel=1;
			parallel_value=coordinate[1][0];
		}
	}
	
	
	public int[][] make_kill()
	{	
		
	
		
		return kill;		
	}
	
	public boolean hit(int x, int y)
	{
		count--;
		if(count==0)
			return true;
		else return false;
	}
	
}
