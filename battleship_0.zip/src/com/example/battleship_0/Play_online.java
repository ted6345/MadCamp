package com.example.battleship_0;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

public class Play_online extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.play_online);
    }
    
    
    public void nextClick(View v)
    {
    	Intent intent = new Intent(this,Play_alone.class);
    	startActivity(intent);

    }
    public void previousClick(View v)
    {
    	finishActivity(0);
    }

    public void refreshClick(View v)
    {
    	//refresh�� �´� �޼ҵ�
    	
    	
    	
    	
    	
    }
    public void autoClick(View v)
    {
    	//auto�� �´� �޼ҵ�
    	
    	
    }
}
