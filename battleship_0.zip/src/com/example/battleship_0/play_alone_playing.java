package com.example.battleship_0;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;
import android.widget.Toast;

public class play_alone_playing extends Activity {
	
	
	protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        
        final Intent play_alone_intent = new Intent(this,Play_alone.class);
        final Intent play_online_intent = new Intent(this,Play_online.class);
        
        
        
        findViewById(R.id.play_alone).setOnClickListener(new OnClickListener() {
		
        	
			@Override
			public void onClick(View v) {
				
				
				
	    	startActivity(play_alone_intent);	
			
		    }
		});
        findViewById(R.id.play_online).setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {	
	    	startActivity(play_online_intent);	
		    }
		});
        
        
    }
	
	
	
}
